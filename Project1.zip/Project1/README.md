#Run 'make' command to compile the first project

#After you have run make execute './CLIShell'


#Known Bugs---
#	If the user has entered 'history' need to exit twice to exit the program
#	
